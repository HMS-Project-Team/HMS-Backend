package com.example.hms.HMS;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HmsApplicationTests {

	@Test
	void contextLoads() {
	}

}
