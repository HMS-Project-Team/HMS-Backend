package com.example.hms.HMS.services;

public interface ReservationTypeService {
}
